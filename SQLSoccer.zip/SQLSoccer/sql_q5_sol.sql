SELECT COUNT(booking_time) 
FROM player_booked
WHERE play_schedule='ST';